from sqlalchemy import create_engine, Column, Integer, String, DateTime
from sqlalchemy.ext.declarative import declarative_base
from sqlalchemy.orm import sessionmaker
from datetime import datetime
import pytz

Base = declarative_base()

class Waitlist(Base):
    __tablename__ = 'waitlist'
    
    id = Column(Integer, primary_key=True)
    name = Column(String)
    seats = Column(Integer)
    requesttime = Column(DateTime, default=lambda: datetime.now(pytz.timezone('America/New_York')))
    status = Column(String)
    assignedtime = Column(DateTime, nullable=True)
    seatedtime = Column(DateTime, nullable=True)
    notes = Column(String)
    phonenumber = Column(String)


class Status(Base):
    __tablename__ = 'status'
    
    id = Column(Integer, primary_key=True)
    name = Column(String, unique=True)
    description = Column(String)


def create_database(db_name='sqlite:///waitlist.db'):
    engine = create_engine(db_name)
    Base.metadata.create_all(engine)
    return engine

def add_entry(session, name, seats, status, notes, phonenumber):
    new_entry = Waitlist(name=name, seats=seats, status=status, notes=notes, phonenumber=phonenumber)
    session.add(new_entry)
    session.commit()

def change_entry(session, entry_id, **kwargs):
    entry = session.query(Waitlist).filter(Waitlist.id == entry_id).first()
    for key, value in kwargs.items():
        if key in ['assignedtime', 'seatedtime']:
            # Convert string to datetime
            value = datetime.strptime(value, '%Y-%m-%d %H:%M').replace(tzinfo=pytz.timezone('America/New_York'))
        setattr(entry, key, value)
    session.commit()
def remove_entry(session, entry_id):
    entry = session.query(Waitlist).filter(Waitlist.id == entry_id).first()
    session.delete(entry)
    session.commit()
def get_session(db_name='sqlite:///waitlist.db'):
    engine = create_engine(db_name)
    Session = sessionmaker(bind=engine)
    return Session()

def query_entries(session, name=None, status=None, phonenumber=None, requesttime=None):
    query = session.query(Waitlist)
    if name:
        query = query.filter(Waitlist.name.like(f'%{name}%'))  # Changed to LIKE
    elif status:
        query = query.filter(Waitlist.status != status)  # Changed to NOT EQUALS
    elif phonenumber:
        query = query.filter(Waitlist.phonenumber.like(f'%{phonenumber}%'))  # Changed to LIKE
    elif requesttime:
        query = query.filter(Waitlist.requesttime == requesttime)
    else:
        query= session.query(Waitlist)  # Default to all entries if no filters are applied    

    return query.all()


def convert_sqlite_to_json(entries):
    return [
        {
            'id': entry.id,
            'name': entry.name,
            'seats': entry.seats,
            'requesttime': entry.requesttime.strftime('%Y-%m-%d %H:%M'),  # Changed format
            'status': entry.status,
            'notes': entry.notes,
            'phonenumber': entry.phonenumber,
            'assignedtime': entry.assignedtime.strftime('%Y-%m-%d %H:%M') if entry.assignedtime else None,
            'seatedtime': entry.seatedtime.strftime('%Y-%m-%d %H:%M') if entry.seatedtime else None
        } for entry in entries
    ]       

def get_entry_by_id(session, entry_id):
    return session.query(Waitlist).filter(Waitlist.id == entry_id).first()

def check_phone_number_status_exists(session, phonenumber, status):
    return session.query(Waitlist).filter(
        Waitlist.phonenumber == phonenumber,
        Waitlist.status == status
    ).first() is not None


def get_waitlist_status(session):
    return session.query(Status).first()

def update_waitlist_status(session, status_name, description):
    status = session.query(Status).filter(Status.name == status_name).first()
    if not status:
        status = Status(name=status_name, description=description)
        session.add(status)
    else:
        status.description = description
    session.commit()
    return status   

