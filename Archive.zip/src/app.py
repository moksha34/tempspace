from flask import Flask, request, jsonify
from flask_restx import Api, Resource, fields
import config as cf
from utils import dbutils as dbu
app = Flask(__name__)
api = Api(app)

waitlist = []
#create the database if it doesn't exist
dbu.create_database(cf.DB_URL)




waitlist_model = api.model('Waitlist', {
    'name': fields.String(required=True, description='Name of the person'),
    'seats': fields.Integer(required=True, description='Number of seats'),
    'phone': fields.String(required=True, description='Phone number'),
    'notes': fields.String(required=False, description='Additional notes')
})

@api.route('/waitlist')
class WaitlistResource(Resource):
    @api.doc('get_waitlist')
    def get(self):
        waitlist=dbu.query_entries(dbu.get_session(cf.DB_URL))
        waitlist = dbu.convert_sqlite_to_json(waitlist)
        return jsonify(waitlist)

    @api.doc('add_to_waitlist')
    @api.expect(waitlist_model)
    def post(self):
        try:
            session = dbu.get_session(cf.DB_URL)
            new_entry = request.json
            exists= dbu.check_phone_number_status_exists(session, new_entry.get("phone","UNKNOWN"), cf.STATUS_WAITING)  
            if exists:
                
                return {"message": "Entry with this phone number already exists in the waiting list."}, 400
            dbu.add_entry(session,new_entry.get("name","UNKNOWN") , seats=new_entry.get("seats",0), status="WAITING", notes=new_entry.get("notes",""),phonenumber= new_entry.get("phone","UNKNOWN"))
        finally:
            session.close()

      
        return new_entry, 201

    @api.doc('delete_waitlist')
    @api.expect(api.model('DeleteEntry', {
        'id': fields.Integer(required=True, description='ID of the entry to delete')
    }))
    def delete(self):
        session = dbu.get_session(cf.DB_URL)
        try:
            entry_id = request.json.get('id')
            dbu.remove_entry(session, entry_id)  # Assuming you have a delete_entry function
        finally:
            session.close()
        return '', 204

@api.route('/waitlist/<int:entry_id>')
class WaitlistEntryResource(Resource):
    @api.doc('get_waitlist_entry')
    def get(self, entry_id):
        session = dbu.get_session(cf.DB_URL)
        try:
            entry = dbu.get_entry_by_id(session, entry_id)
            if not entry:
                return {'message': 'Entry not found'}, 404
            return dbu.convert_sqlite_to_json([entry])[0]
        finally:
            session.close()

    @api.doc('update_waitlist_entry')
    @api.expect(waitlist_model)
    def put(self, entry_id):
        session = dbu.get_session(cf.DB_URL)
        try:
            updated_data = request.json
            dbu.change_entry(session, entry_id, **updated_data)
            updated_entry = dbu.get_entry_by_id(session, entry_id)
            return dbu.convert_sqlite_to_json([updated_entry])[0]
        finally:
            session.close() 

            # ... existing code ...

            @api.route('/waitlist/status')
            class WaitlistStatusResource(Resource):
                @api.doc('get_waitlist_status')
                def get(self):
                    # Assuming you have a function to get the status of the waitlist
                    status = dbu.get_waitlist_status()  # Implement this function as needed
                    return jsonify(status)

                @api.doc('update_waitlist_status')
                @api.expect(api.model('UpdateStatus', {
                    'status': fields.String(required=True, description='New status for the waitlist')
                }))
                def post(self):
                    new_status = request.json.get('status')
                    # Assuming you have a function to update the status of the waitlist
                    dbu.update_waitlist_status(new_status)  # Implement this function as needed
                    return {'message': 'Status updated successfully'}, 200



if __name__ == '__main__':
    app.run(debug=True)
