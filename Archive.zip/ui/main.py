import os
import pathlib
from datetime import datetime,timezone
from typing import List, Dict, Any

import requests

from dash import Dash, html, dcc, Input, Output, State, dash_table
import dash
import dash_bootstrap_components as dbc

from dash.exceptions import PreventUpdate

from flask import send_from_directory
import re
import pytz
from datetime import datetime
import pytz
WAITLIST_GET_URL = os.getenv("WAITLIST_GET_URL", "http://localhost:5000/waitlist")
WAITLIST_POST_URL = os.getenv("WAITLIST_POST_URL", "http://localhost:5000/waitlist")
WAITLIST_STATUS_URL = os.getenv("WAITLIST_STATUS_URL", "http://localhost:5000/waitlist/status")
# Item-level operations (PATCH/DELETE) will hit this URL with {id} substituted
WAITLIST_ITEM_URL_TEMPLATE = os.getenv(
    "WAITLIST_ITEM_URL_TEMPLATE",
    WAITLIST_POST_URL.rstrip("/") + "/{id}",
)

# What status value should “Assign” set?
ASSIGN_STATUS_VALUE = os.getenv("ASSIGN_STATUS_VALUE", "ASSIGNING")

MEDIA_DIR = os.getenv("MEDIA_DIR", "media")
AUTO_REFRESH_SECONDS = int(os.getenv("AUTO_REFRESH_SECONDS", "2"))
MEDIA_ROTATE_SECONDS = 10

pathlib.Path(MEDIA_DIR).mkdir(parents=True, exist_ok=True)

IMAGE_EXTS = {".png", ".jpg", ".jpeg", ".gif", ".bmp", ".webp"}
VIDEO_EXTS = {".mp4", ".webm", ".ogg", ".m4v"}

app = Dash(
    __name__,
    use_pages=True,
    external_stylesheets=[dbc.themes.CYBORG, dbc.icons.BOOTSTRAP],
    title="Waitlist Dashboard",suppress_callback_exceptions=True
)
server = app.server

@server.route("/media/<path:filename>")
def media(filename):
    return send_from_directory(MEDIA_DIR, filename)

def scan_media() -> List[Dict[str, Any]]:
    items: List[Dict[str, Any]] = []
    root = pathlib.Path(MEDIA_DIR)
    if not root.exists():
        return items
    for p in sorted(root.rglob("*")):
        if not p.is_file():
            continue
        ext = p.suffix.lower()
        media_type = None
        if ext in IMAGE_EXTS:
            media_type = "image"
        elif ext in VIDEO_EXTS:
            media_type = "video"
        if media_type:
            rel = p.relative_to(root).as_posix()
            items.append(
                {
                    "name": p.stem,
                    "url": f"/media/{rel}",
                    "type": media_type,
                    "path": rel,
                }
            )
    return items

navbar = dbc.Navbar(
    dbc.Container(
        [
            dbc.NavbarBrand("Kachiguda Junction", class_name="ms-2"),
            dbc.Nav(
                [
                    dbc.NavItem(dbc.NavLink("Home", href="/")),
                    dbc.NavItem(dbc.NavLink("Add to Waitlist", href="/add_waitlist")),
                    dbc.NavItem(dbc.NavLink("Waitlist", href="/waitlist")),

                ],
                class_name="ms-auto",
            ),
        ]
    ),
    color="dark",
    dark=True,
    sticky="top",
)

def media_card():
    media_items = scan_media()
    if not media_items:
        body = html.Div(
            [
                html.Div(
                    [
                        html.I(className="bi bi-folder2-open me-2"),
                        html.Span("Drop images/videos into the 'media' folder to play them here."),
                    ],
                    className="text-muted",
                ),
                html.Div(
                    "Supported: images (png/jpg/jpeg/gif/webp), videos (mp4/webm/ogg/m4v)",
                    className="small text-muted mt-2",
                ),
            ]
        )
    else:
        body = html.Div(
            [
                dcc.Store(id="media-store", data=media_items),
                dcc.Store(id="media-index", data=0),
                dcc.Interval(id="media-rotate", interval=MEDIA_ROTATE_SECONDS * 1000, n_intervals=0),
                html.Div(id="media-display", className="rounded overflow-hidden shadow"),
            ]
        )
    return dbc.Card(
        [
            dbc.CardHeader(html.H4("Media Player", className="m-0")),
            dbc.CardBody(body),
        ],
        className="h-100",
    )

def waitlist_card():
    return dbc.Card(
        [
            dbc.CardHeader(
                dbc.Row(
                    [
                        dbc.Col(html.H4("Current Waitlist", className="m-0"), xs=8),
                        dbc.Col(
                            dbc.Button(
                                [html.I(className="bi bi-arrow-clockwise me-1"), "Refresh"],
                                id="refresh-btn",
                                color="secondary",
                                size="sm",
                                className="float-end",
                            ),
                            xs=4,
                        ),
                    ],
                    align="center",
                )
            ),
            dbc.CardBody(
                [
                    dcc.Interval(id="waitlist-interval", interval=AUTO_REFRESH_SECONDS * 1000, n_intervals=0),
                    dash_table.DataTable(
    id="waitlist-table",
    columns=[
        {"name": "Name", "id": "name"},
        {"name": "Seats", "id": "seats", "type": "numeric"},
        {"name": "Status", "id": "status", "type": "text"},
        {"name": "reserved at", "id": "reserved at", "type": "text"},
        {"name": "wait (min)", "id": "wait_mins", "type": "numeric"},
    ],
    data=[],
    sort_action="native",
    filter_action="none",
    page_size=10,
    style_table={"overflowX": "auto"},
    style_cell={"whiteSpace": "normal", "height": "auto"},
    style_header={"backgroundColor": "#1f2733", "fontWeight": "bold"},
    style_data_conditional=[
        # WAITING -> orange
        {
            "if": {"column_id": "status", "filter_query": '{status} = "WAITING"'},
            "color": "#fd7e14", "fontWeight": "700",
        },
        # ASSIGNING -> green
        {
            "if": {"column_id": "status", "filter_query": '{status} = "ASSIGNING"'},
            "color": "#20c997", "fontWeight": "700",
        },
    ],
),

                    html.Div(id="waitlist-error", className="text-danger mt-3"),
                ]
            ),
        ],
        className="h-100",
    )

index_layout = dbc.Container(
    [
        navbar,
        dbc.Container(
            [
                # Interval to poll the waitlist for whether to show banner vs table
                dcc.Interval(id="home-interval", interval=AUTO_REFRESH_SECONDS * 1000, n_intervals=0),

                dbc.Row(
                    [
                        dbc.Col(media_card(), md=8, className="mb-8", id="home-left"),
                        dbc.Col(  # dynamic right-hand pane
                            html.Div(id="home-right-pane"),
                            md=4,
                            className="mb-4",
                            id="home-right",
                        ),
                    ],
                    className="mt-3",
                ),
            ],
            fluid=True,
        ),
    ],
    fluid=True,
)

add_layout = dbc.Container(
    [
        navbar,
        dbc.Container(
            [
                dbc.Row(
                    dbc.Col(
                        dbc.Card(
                            [
                                dbc.CardHeader(html.H4("Add a Party to the Waitlist", className="m-0")),
                                dbc.CardBody(
                                    [
                                        dbc.Alert(
                                            id="form-alert",
                                            is_open=False,
                                            dismissable=True,
                                            duration=4000,
                                        ),
                                        dbc.Form(
                                            [
                                                dbc.Row(
                                                    [
                                                        dbc.Col(
                                                            [
                                                                dbc.Label("Name"),
                                                                dbc.Input(id="name", placeholder="Full name", type="text", required=True),
                                                            ],
                                                            md=6,
                                                        ),
                                                        dbc.Col(
                                                            [
                                                                dbc.Label("Phone Number"),
                                                                dbc.Input(id="phone", placeholder="(555) 555-5555", type="tel", required=True),
                                                            ],
                                                            md=6,
                                                        ),
                                                    ]
                                                ),
                                                dbc.Row(
                                                    [
                                                        dbc.Col(
                                                            [
                                                                dbc.Label("Seats"),
                                                                dbc.Input(id="seats", type="number", min=1, step=1, value=2, required=True),
                                                            ],
                                                            md=4,
                                                        ),
                                                        dbc.Col(
                                                            [
                                                                dbc.Label("Notes"),
                                                                dbc.Textarea(id="notes", placeholder="Allergies, occasion, etc."),
                                                            ],
                                                            md=8,
                                                        ),
                                                    ]
                                                ),
                                                dbc.Button(
                                                    [html.I(className="bi bi-plus-circle me-2"), "Submit"],
                                                    id="submit-btn",
                                                    color="primary",
                                                    className="mt-3",
                                                ),
                                            ]
                                        ),
                                    ]
                                ),
                            ],
                            className="mt-4",
                        ),
                        md=8,
                        className="mx-auto",
                    )
                )
            ],
            fluid=True,
        ),
    ],
    fluid=True,
)

waitlist_layout = dbc.Container(
    [
        navbar,
        dbc.Container(
            [
                dbc.Row(
                    dbc.Col(
                        dbc.Card(
                            [
                                dbc.CardHeader(
                                    dbc.Row(
                                        [
                                            dbc.Col(html.H4("Manage Waitlist", className="m-0")),
                                            dbc.Col(
                                                dbc.Button(
                                                    [html.I(className="bi bi-arrow-clockwise me-1"), "Refresh"],
                                                    id="wl-admin-refresh",
                                                    color="secondary",
                                                    size="sm",
                                                    className="float-end",
                                                ),
                                                width="auto",
                                            ),
                                        ],
                                        align="center",
                                    )
                                ),
                                dbc.CardBody(
                                    [
                                        dcc.Interval(id="wl-admin-interval", interval=15_000, n_intervals=0),
                                        dbc.Alert(id="wl-admin-alert", is_open=False, duration=4000),
                                        dash_table.DataTable(
                                            id="wl-admin-table",
                                            columns=[
                                                {"name": "ID", "id": "id", "editable": False},
                                                {"name": "Name", "id": "name", "editable": True},
                                                {"name": "Seats", "id": "seats", "type": "numeric", "editable": True},
                                                {"name": "Status", "id": "status", "type": "text", "editable": True},
                                                {"name": "Notes", "id": "notes", "editable": True},
                                                {"name": "Phone Number", "id": "phonenumber", "editable": True},
                                                # in-row action columns (not editable)
                                                {"name": "", "id": "assign", "editable": False},
                                                {"name": "", "id": "delete", "editable": False},
                                            ],
                                            data=[],
                                            editable=True,
                                            page_size=10,
                                            sort_action="native",
                                            filter_action="none",
                                            cell_selectable=True,  # click cells to trigger actions
                                            style_table={"overflowX": "auto"},
                                            style_cell={"whiteSpace": "normal", "height": "auto"},
                                            style_header={"backgroundColor": "#1f2733", "fontWeight": "bold"},
                                            # Make action cells look like buttons
                                            style_data_conditional=[
                                                {
                                                    "if": {"column_id": "assign"},
                                                    "backgroundColor": "#0d6efd", "color": "white",
                                                    "textAlign": "center", "cursor": "pointer",
                                                    "fontWeight": "600", "border": "1px solid #0b5ed7",
                                                    "borderRadius": "25rem",  # Changed to borderRadius
                                                    "padding": "0.5rem 1rem",  # Added padding for button effect
                                                },
                                           
                                                {
                                                    "if": {"column_id": "delete"},
                                                    "backgroundColor": "#dc3545", "color": "white",
                                                    "textAlign": "center", "cursor": "pointer",
                                                    "fontWeight": "600", "border": "1px solid #bb2d3b",
                                                    "borderRadius": "25rem",  # Changed to borderRadius
                                                    "padding": "0.5rem 1rem",  # Added padding for button effect
                                                },
                                            ],
                                        ),
                                    ]
                                ),
                            ],
                            className="mt-4",
                        ),
                        md=10,
                        className="mx-auto",
                    )
                )
            ],
            fluid=True,
        ),
    ],
    fluid=True,
)

def come_in_card():
    return dbc.Card(
        [
            dbc.CardBody(
                [
                    html.Div(
                        [
                            html.I(className="bi bi-door-open me-2"),
                            html.Span("Come on in", className="fw-bold"),
                        ],
                        className="display-4",
                    ),
                    html.Div("No wait right now. We’re ready for you!", className="mt-2"),
                ]
            )
        ],
        className="h-100 border-success",
        color="success",
        inverse=True,
    )

dash.register_page("index", path="/", layout=index_layout)
dash.register_page("add_waitlist", path="/add_waitlist", layout=add_layout)
dash.register_page("waitlist", path="/waitlist", layout=waitlist_layout)


def _humanize_ts(val):
    """Return a readable timestamp string from ISO string or epoch seconds."""
    if not val:
        return ""
    try:
        if isinstance(val, (int, float)):
            dt = datetime.fromtimestamp(val)
        else:
            # handle common API formats like "2025-08-12T17:05:00Z"
            iso = str(val).replace("Z", "+00:00")
            dt = datetime.fromisoformat(iso)
        return dt.strftime("%Y-%m-%d %H:%M")
    except Exception:
        return str(val)

def _is_valid_us_phone(phone: str):
    """
    Accepts common US/Canada formats:
      - 10 digits, e.g. 5555555555 or (555) 555-5555
      - 11 digits starting with '1', e.g. 15555555555 or +1 555 555 5555
    Returns (is_valid: bool, normalized_10: str) where normalized_10 is the 10-digit local number.
    """
    raw = phone or ""
    digits = _normalize_phone(raw)

    if len(digits) == 10:
        return True, digits
    if len(digits) == 11 and digits.startswith("1"):
        return True, digits[1:]  # strip country code
    return False, ""



def fetch_waitlist():
    """
    GET the waitlist from WAITLIST_GET_URL.
    Accepts API responses shaped as:
      - [{"name":..., "phone_number":..., "seats":..., "notes":..., "created_at":...}, ...]
      - {"results": [ ...same as above... ]}
    Returns (rows, error_message). rows is list for the DataTable or dash.no_update on error.
    """
    try:
        r = requests.get(WAITLIST_GET_URL, timeout=8)
        r.raise_for_status()
        payload = r.json()

        items = payload.get("results", payload) if isinstance(payload, dict) else payload
        if not isinstance(items, list):
            raise ValueError("Unexpected response shape")

        rows = []
        for it in items:
            status = (it.get("status", "") or "").upper()
            if status not in ("WAITING", "ASSIGNING"):
              continue  # ← hide all other statuses on the main page

            req_time = it.get("requesttime")
            rows.append(
        {
            "name": it.get("name", ""),
            "seats": it.get("seats"),
            "reserved at": _humanize_ts(req_time),
            "status": status,
            "wait_mins": _wait_minutes(req_time),
        }
         )
        return rows, ""

       
    except Exception as e:
        return dash.no_update, f"Failed to GET {WAITLIST_GET_URL}: {e}"




def _normalize_phone(phone: str) -> str:
    """Keep digits only; simple normalization so your API gets a clean phone_number."""
    return re.sub(r"\D", "", phone or "")

def build_waitlist_payload(name: str, phone: str, seats, notes: str) -> dict:
    """Validate and shape the payload expected by your API."""
    name = (name or "").strip()
    phone = _normalize_phone(phone)
    try:
        seats = int(seats)
    except Exception:
        seats = 0

    if not name or not phone or seats < 1:
        raise ValueError("Please provide name, phone, and at least 1 seat.")

    return {
        "name": name,
        "phone": phone,   # align with your API's field name
        "seats": seats,
        "notes": (notes or "").strip(),
    }

def post_waitlist(payload: dict) -> dict:
    """Send POST to add a waitlist entry. Returns parsed JSON (if any)."""
    
    r = requests.post(WAITLIST_POST_URL, json=payload, timeout=8)
    if r.status_code == 400:
        # Handle common bad request errors
        try:
            error_data = r.json()
            error_message = error_data.get("message", "Bad request")
            raise ValueError(error_message)
        except ValueError:
            raise ValueError(error_message)
    else:

        r.raise_for_status()
        try:
            return r.json()  # some APIs return the created object
        except ValueError:
            # no JSON body (e.g., 201 Created with empty body)
            return {"ok": True, "status_code": r.status_code}



def fetch_wait_status():
    """
    Calls WAITLIST_STATUS_URL and returns ("YES"|"NO"|None, error_message).
    Accepts either:
      - {"status": "YES"} / {"status": "NO"}
      - "YES" / "NO" (plain string)
    """
    try:
        r = requests.get(WAITLIST_STATUS_URL, timeout=6)
        r.raise_for_status()
        try:
            data = r.json()
        except ValueError:
            # not JSON — maybe plain text "YES"/"NO"
            txt = (r.text or "").strip().upper()
            return (txt if txt in ("YES", "NO") else None), ""
        if isinstance(data, dict):
            val = (str(data.get("status", "")).strip().upper())
            return (val if val in ("YES", "NO") else None), ""
        if isinstance(data, str):
            val = data.strip().upper()
            return (val if val in ("YES", "NO") else None), ""
        return None, "Unexpected /waitlist/status response shape"
    except Exception as e:
        return None, f"Failed to GET {WAITLIST_STATUS_URL}: {e}"


def fetch_waitlist_admin():
    """
    GET waitlist and map to admin table fields:
    id, name, seats, waittime, notes, phonenumber
    Accepts either a list or {"results": [...]}
    """
    try:
        r = requests.get(WAITLIST_GET_URL, timeout=8)
        r.raise_for_status()
        payload = r.json()
        items = payload.get("results", payload) if isinstance(payload, dict) else payload
        rows = []
        for it in (items or []):
           status = (it.get("status") or "").upper()
           action_label = "assign" if status == "WAITING" else ("seated" if status == "ASSIGNING" else "")
           rows.append({
        "id": it.get("id") or it.get("_id") or it.get("uuid"),
        "name": it.get("name", ""),
        "seats": it.get("seats"),
        "status": status,
        "notes": it.get("notes", ""),
        "phonenumber": it.get("phonenumber") or it.get("phone_number") or it.get("phoneNumber", ""),
        "assign": action_label,   # ← label becomes "assign" or "seated" per status
        "delete":"delete",
    })
        return rows, ""
    except Exception as e:
        return [], f"Failed to GET {WAITLIST_GET_URL}: {e}"

def patch_waitlist_item(item_id, payload: dict):
    """PATCH a single waitlist record."""
    url = WAITLIST_ITEM_URL_TEMPLATE.format(id=item_id)
    r = requests.put(url, json=payload, timeout=8)
    r.raise_for_status()
    return r.json() if r.headers.get("content-type","").startswith("application/json") else {"ok": True}

def delete_waitlist_item(item_id):
    """DELETE a single waitlist record."""
    url = WAITLIST_POST_URL
    payload={"id": item_id}  
    r = requests.delete(url,json=payload,timeout=8)
    r.raise_for_status()
    return {"ok": True}





def _wait_minutes(val) -> int:
    """
    Return total wait time in whole minutes from a timestamp (epoch or ISO).
    Falls back to 0 if missing or unparseable.
    """
    if not val:
        return 0
    print(val)
    try:
        val=val
        dt = datetime.strptime(val, "%Y-%m-%d %H:%M")
        # assume NY if no timezone info
        
       
        now = datetime.now(tz=pytz.timezone('America/New_York')).strftime("%Y-%m-%d %H:%M")
        now=datetime.strptime(now,"%Y-%m-%d %H:%M")# current time in UTC
        print(f"Calculating wait time: now={now}, dt={dt}")
        print((now-dt))

        return max(0, int((now-dt).total_seconds() // 60))  # convert to minutes, ensure non-negative
    except Exception as e:
        print(e)
        return 0


def build_waitlist_payload(name: str, phone: str, seats, notes: str) -> dict:
    name = (name or "").strip()
    try:
        seats = int(seats)
    except Exception:
        seats = 0

    ok, normalized_10 = _is_valid_us_phone(phone)

    if not name or seats < 1:
        raise ValueError("Please provide name and at least 1 seat.")
    if not ok:
        raise ValueError("Please enter a valid US/Canada phone number (10 digits).")

    return {
        "name": name,
        "phone": normalized_10,  # keep your current API field; now normalized to 10 digits
        "seats": seats,
        "notes": (notes or "").strip(),
    }



@app.callback(
    Output("waitlist-table", "data"),
    Output("waitlist-error", "children"),
    Input("waitlist-interval", "n_intervals"),
    Input("refresh-btn", "n_clicks"),
    prevent_initial_call=False,
)
def refresh_waitlist_table(_n_intervals, _n_clicks):
    rows, err = fetch_waitlist()
    if err:
        return dash.no_update, err
    return rows, ""


@app.callback(
    Output("media-display", "children"),
    Output("media-index", "data"),
    Input("media-rotate", "n_intervals"),
    State("media-store", "data"),
    State("media-index", "data"),
)
def rotate_media(n_intervals, media_items, index):
    if not media_items:
        return html.Div(), 0
    new_index = (index + 1) % len(media_items) if index is not None else 0
    chosen = media_items[new_index]
    if chosen["type"] == "image":
        return html.Img(src=chosen["url"], style={"width": "100%", "height": "auto", "display": "block", "borderRadius": "0.5rem"}), new_index
    else:
        return html.Video(src=chosen["url"], controls=True, autoPlay=True, muted=True, loop=True, style={"width": "100%", "display": "block", "borderRadius": "0.5rem"}), new_index


@app.callback(
    Output("form-alert", "children"),
    Output("form-alert", "color"),
    Output("form-alert", "is_open"),
    Output("name", "value"),
    Output("phone", "value"),
    Output("seats", "value"),
    Output("notes", "value"),
    Input("submit-btn", "n_clicks"),
    State("name", "value"),
    State("phone", "value"),
    State("seats", "value"),
    State("notes", "value"),
    prevent_initial_call=True,
)
def submit_waitlist(n_clicks, name, phone, seats, notes):
    if not n_clicks:
        raise dash.exceptions.PreventUpdate
    # Build + validate payload
    try:
        payload = build_waitlist_payload(name, phone, seats, notes)
    except ValueError as ve:
        return str(ve), "warning", True, name, phone, seats, notes

    # POST to API
    try:
        _ = post_waitlist(payload)
        # Success: clear form
        return "Added to waitlist successfully.", "success", True, "", "", 2, ""
    except Exception as e:
        # Keep user inputs, show error
        return f"Failed to submit to waitlist \n {e}", "danger", True, name, phone, seats, notes


# Load & refresh admin table
@app.callback(
    Output("wl-admin-table", "data"),
    Output("wl-admin-alert", "is_open"),
    Output("wl-admin-alert", "color"),
    Output("wl-admin-alert", "children"),
    Input("wl-admin-interval", "n_intervals"),
    Input("wl-admin-refresh", "n_clicks"),
    prevent_initial_call=False,
    suppress_callback_exceptions=True
)
def load_admin_table(_n, _click):
    rows, err = fetch_waitlist_admin()
    if err:
        return rows, True, "danger", err
    return rows, False, "info", ""



@app.callback(
    Output("home-right-pane", "children"),
    Input("home-interval", "n_intervals")
)
def update_home_right(_n):
    # 1) Ask the status endpoint first
    status, status_err = fetch_wait_status()

    # If status is explicitly NO => show banner
    if status == "NO":
        return come_in_card()

    # If status is explicitly YES => show table
    if status == "YES":
        return waitlist_card()

    # Fallback behavior if the status endpoint errors or returns unexpected data:
    # Try to infer from the current waitlist (keeps previous UX as a backup).
    rows, err = fetch_waitlist()
    if err:
        return dbc.Alert(
            f"Could not load waitlist status: {status_err or err}",
            color="danger",
            className="mb-0"
        )

    if len(rows or []) == 0:
        return come_in_card()

    return waitlist_card()









@app.callback(
    Output("wl-admin-table", "data", allow_duplicate=True),
    Output("wl-admin-alert", "is_open", allow_duplicate=True),
    Output("wl-admin-alert", "color", allow_duplicate=True),
    Output("wl-admin-alert", "children", allow_duplicate=True),
    Input("wl-admin-table", "active_cell"),
    State("wl-admin-table", "data"),
    prevent_initial_call=True,
)
def handle_admin_cell_click(active_cell, data):
    # Only react when an action cell is clicked
    if not active_cell:
        raise PreventUpdate
    col = active_cell.get("column_id")
    row_idx = active_cell.get("row")
    if col not in {"assign", "edit", "delete"}:
        raise PreventUpdate
    if row_idx is None or row_idx < 0 or row_idx >= len(data):
        raise PreventUpdate

    row = data[row_idx]
    item_id = row.get("id")
    if not item_id:
        return dash.no_update, True, "danger", "Selected row is missing an 'id'."

    try:
        if col == "assign":
            curr_status = (row.get("status") or "").upper()
            if curr_status == "WAITING":
               new_status = ASSIGN_STATUS_VALUE  # typically "ASSIGNING"
            elif curr_status == "ASSIGNING":
               new_status = "SEATED"
            else:
               return dash.no_update, True, "info", f"No action for status '{curr_status}'."

        patch_waitlist_item(item_id, {"status": new_status})
        rows, _ = fetch_waitlist_admin()
        return rows, True, "success", f"Record {item_id} set to {new_status}."

        if col == "delete":
            delete_waitlist_item(item_id)
            rows, _ = fetch_waitlist_admin()
            return rows, True, "success", f"Record {item_id} deleted."

        # Fallback (shouldn't hit)
        raise PreventUpdate

    except Exception as e:
        action = {"assign": "assign", "edit": "edit", "delete": "delete"}[col]
        return dash.no_update, True, "danger", f"Failed to {action} record {item_id}: {e}"


def admin_actions(assign_clicks, edit_clicks, delete_clicks, data, selected_rows):
    # Which button fired?
    ctx = dash.callback_context
    if not ctx.triggered:
        raise dash.exceptions.PreventUpdate
    trigger_id = ctx.triggered[0]["prop_id"].split(".")[0]

    # Validate selection
    if not selected_rows:
        return dash.no_update, True, "warning", "Select a row first."

    row_idx = selected_rows[0]
    try:
        row = data[row_idx]
    except Exception:
        return dash.no_update, True, "danger", "Invalid selection."

    item_id = row.get("id")
    if not item_id:
        return dash.no_update, True, "danger", "Selected row is missing an 'id'."

    try:
        if trigger_id == "wl-assign-btn":
            patch_waitlist_item(item_id, {"status": ASSIGN_STATUS_VALUE})
            # Optionally update local row immediately
            # (If your API returns the updated record, you could refetch here instead)
            rows, _ = fetch_waitlist_admin()
            return rows, True, "success", f"Record {item_id} assigned."

        if trigger_id == "wl-edit-btn":
            # Build payload from current edited cells
            payload = {
                "name": row.get("name"),
                "seats": row.get("seats"),
                "notes": row.get("notes"),
                "phone_number": row.get("phonenumber"),
            }
            # Include common variants for wait time to maximize compatibility
            wt = row.get("waittime")
            if wt is not None:
                payload["waittime"] = wt
                payload["wait_time"] = wt

            patch_waitlist_item(item_id, payload)
            rows, _ = fetch_waitlist_admin()
            return rows, True, "success", f"Record {item_id} updated."

        if trigger_id == "wl-delete-btn":
            delete_waitlist_item(item_id)
            rows, _ = fetch_waitlist_admin()
            return rows, True, "success", f"Record {item_id} deleted."

        # Fallback
        return dash.no_update, True, "warning", "Unknown action."

    except Exception as e:
        action = "assign" if trigger_id == "wl-assign-btn" else "edit" if trigger_id == "wl-edit-btn" else "delete"
        return dash.no_update, True, "danger", f"Failed to {action} record {item_id}: {e}"



if __name__ == "__main__":
    app.run(debug=True, host="0.0.0.0", port=8050)
